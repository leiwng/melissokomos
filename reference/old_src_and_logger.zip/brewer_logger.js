const pino = require("pino")

const logger = (model_name, dbg_level, log_dest) => {
    return pino(
        {
            name: model_name,
            level: dbg_level,
            formatter: (level, message) => {
                const now = new Date()
                return `[${now.toISOString()}] ${level}: ${message}`
            },
        },
        pino.destination(log_dest)
    )
}

module.exports = logger